# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
# --------------------------------------------------------
# References:
# DiT: https://github.com/facebookresearch/DiT
# GLIDE: https://github.com/openai/glide-text2im
# MAE: https://github.com/facebookresearch/mae/blob/main/models_mae.py
# --------------------------------------------------------
from collections import OrderedDict

import torch
import torch.nn as nn

from atm.policy.RoboticsDiffusionTransformer.models.rdt.blocks import (FinalLayer, RDTBlock, TimestepEmbedder,
                               get_1d_sincos_pos_embed_from_grid,
                               get_multimodal_cond_pos_embed)


#动作长度变了，这个位置编码要改

#pretraining finetuning是没有智能体编码的，其他都有

# 如果一条样本是机器人样本，action只有前7维有意义
class RDT(nn.Module):
    """
    Class for Robotics Diffusion Transformers.
    """
    def __init__(
        self,
        output_dim=128,
        horizon=32,
        hidden_size=1152,
        depth=28,
        num_heads=16,
        max_lang_cond_len=1024,
        img_cond_len=4096,
        lang_pos_embed_config=None,
        img_pos_embed_config=None,
        dtype=torch.float32
    ):
        super().__init__()
        self.horizon = horizon
        self.hidden_size = hidden_size
        self.max_lang_cond_len = max_lang_cond_len
        self.img_cond_len = img_cond_len
        self.dtype = dtype
        self.lang_pos_embed_config = lang_pos_embed_config
        self.img_pos_embed_config = img_pos_embed_config

        self.t_embedder = TimestepEmbedder(hidden_size, dtype=dtype)
        self.freq_embedder = TimestepEmbedder(hidden_size, dtype=dtype)
        
        # We will use trainable sin-cos embeddings
        # [timestep; state; action]
        self.x_pos_embed = nn.Parameter(
            torch.zeros(1, horizon+3, hidden_size))
        # Language conditions
        self.lang_cond_pos_embed = nn.Parameter(
            torch.zeros(1, max_lang_cond_len, hidden_size))
        # Image conditions
        self.img_cond_pos_embed = nn.Parameter(
            torch.zeros(1, img_cond_len, hidden_size))

        self.blocks = nn.ModuleList([
            RDTBlock(hidden_size, num_heads) for _ in range(depth)
        ])

        # self.final_layer = FinalLayer(hidden_size, 256)


        #self.final_layer = FinalLayer(hidden_size, 256)
        #self.final_layer = FinalLayer(hidden_size, 7)


        self.final_layer_robot = FinalLayer(hidden_size, 7)
        ########################
        self.final_layer_human = FinalLayer(hidden_size, 256)
        #4096 256 512

        # 机器人的这个和本体concat在一起，人类的就是人类的
        self.robot = nn.Parameter(torch.zeros(1, self.hidden_size))
        self.human = nn.Parameter(torch.zeros(1, self.hidden_size))

        self.initialize_weights()

    def initialize_weights(self):
        # Initialize transformer layers:
        def _basic_init(module):
            if isinstance(module, nn.Linear):
                torch.nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
        self.apply(_basic_init)

        # Initialize pos_embed by sin-cos embedding
        x_pos_embed = get_multimodal_cond_pos_embed(
            embed_dim=self.hidden_size,
            mm_cond_lens=OrderedDict([
                ('timestep', 1),
                ('ctrl_freq', 1),
                ('state', 1),
                ('action', self.horizon),
            ])
        )
        self.x_pos_embed.data.copy_(torch.from_numpy(x_pos_embed).float().unsqueeze(0))

        if self.lang_pos_embed_config is None:
            lang_cond_pos_embed = get_1d_sincos_pos_embed_from_grid(
                self.hidden_size, torch.arange(self.max_lang_cond_len))
        else:
            lang_cond_pos_embed = get_multimodal_cond_pos_embed(
                embed_dim=self.hidden_size,
                mm_cond_lens=OrderedDict(self.lang_pos_embed_config),
                embed_modality=False
            )
        self.lang_cond_pos_embed.data.copy_(
            torch.from_numpy(lang_cond_pos_embed).float().unsqueeze(0))

        # breakpoint()
        
        if self.img_pos_embed_config is None:
            img_cond_pos_embed = get_1d_sincos_pos_embed_from_grid(
                self.hidden_size, torch.arange(self.img_cond_len))
        else:
            img_cond_pos_embed = get_multimodal_cond_pos_embed(
                embed_dim=self.hidden_size,
                mm_cond_lens=OrderedDict(self.img_pos_embed_config),
                embed_modality=False
            )
        self.img_cond_pos_embed.data.copy_(
            torch.from_numpy(img_cond_pos_embed).float().unsqueeze(0))

        # Initialize timestep and control freq embedding MLP
        nn.init.normal_(self.t_embedder.mlp[0].weight, std=0.02)
        nn.init.normal_(self.t_embedder.mlp[2].weight, std=0.02)
        nn.init.normal_(self.freq_embedder.mlp[0].weight, std=0.02)
        nn.init.normal_(self.freq_embedder.mlp[2].weight, std=0.02)
            
        # Initialize the final layer: zero-out the final linear layer
        nn.init.constant_(self.final_layer_human.ffn_final.fc2.weight, 0)
        nn.init.constant_(self.final_layer_human.ffn_final.fc2.bias, 0)
        nn.init.constant_(self.final_layer_robot.ffn_final.fc2.weight, 0)
        nn.init.constant_(self.final_layer_robot.ffn_final.fc2.bias, 0)

        nn.init.constant_(self.final_layer_human.ffn_final2.fc2.weight, 0)
        nn.init.constant_(self.final_layer_human.ffn_final2.fc2.bias, 0)
        nn.init.constant_(self.final_layer_robot.ffn_final2.fc2.weight, 0)
        nn.init.constant_(self.final_layer_robot.ffn_final2.fc2.bias, 0)

        # nn.init.constant_(self.final_layer_robot.ffn_final.mlp[0].fc2.weight, 0)
        # nn.init.constant_(self.final_layer_robot.ffn_final.mlp[0].fc2.bias, 0)
        # nn.init.constant_(self.final_layer_human.ffn_final.mlp[0].fc2.weight, 0)
        # nn.init.constant_(self.final_layer_human.ffn_final.mlp[0].fc2.bias, 0)
        # nn.init.constant_(self.final_layer_robot.ffn_final.mlp[2].fc2.weight, 0)
        # nn.init.constant_(self.final_layer_robot.ffn_final.mlp[2].fc2.bias, 0)
        # nn.init.constant_(self.final_layer_human.ffn_final.mlp[2].fc2.weight, 0)
        # nn.init.constant_(self.final_layer_human.ffn_final.mlp[2].fc2.bias, 0)
        
        # Move all the params to given data type:
        self.to(self.dtype)

    
    #没有本地状态就用两个t

    def forward(self, x, freq, t, lang_c, img_c, state_c, isrobot, lang_mask=None, img_mask=None):
        """
        Forward pass of RDT.
        
        x: (B, T, D), state + action token sequence, T = horizon + 1,
            dimension D is assumed to be the same as the hidden size.
        freq: (B,), a scalar indicating control frequency.
        t: (B,) or (1,), diffusion timesteps.
        lang_c: (B, L_lang, D) or None, language condition tokens (variable length),
            dimension D is assumed to be the same as the hidden size.
        img_c: (B, L_img, D) or None, image condition tokens (fixed length),
            dimension D is assumed to be the same as the hidden size.
        lang_mask: (B, L_lang) or None, language condition mask (True for valid).
        img_mask: (B, L_img) or None, image condition mask (True for valid).
        """

        lang_mask = None


        t = self.t_embedder(t).unsqueeze(1)             # (B, 1, D) or (1, 1, D)
        #freq = self.freq_embedder(freq).unsqueeze(1)    # (B, 1, D)
        # Append timestep to the input tokens
        if t.shape[0] == 1:
            t = t.expand(x.shape[0], -1, -1)


        # 这部分要修改
        #x = torch.cat([t, state_c, x], dim=1)               # (B, T+1, D)
        #x = torch.cat([t, t, x], dim=1)               # (B, T+1, D)

        # 根据 isrobot 分组
        robot_mask = isrobot  # 机器人数据的布尔掩码
        human_mask = ~isrobot  # 人类数据的布尔掩码
        # 初始化结果张量
        x_final = torch.zeros(
            x.shape[0], x.shape[1] + t.shape[1] + t.shape[1], x.shape[2],  # 最终拼接后的维度
            device=x.device
        )
        # 分组处理
        if robot_mask.any():  # 如果有机器人数据
            robot_t = t[robot_mask]
            robot_state_c = state_c[robot_mask]
            robot_x = x[robot_mask]
            # 对机器人数据执行拼接
            robot_x_final = torch.cat([robot_t, robot_state_c + self.robot, robot_x], dim=1)
            #robot_x_final = torch.cat([robot_t, robot_state_c, robot_x], dim=1)
            x_final[robot_mask] = robot_x_final

        if human_mask.any():  # 如果有人工数据
            
            human_t = t[human_mask]
            human_x = x[human_mask]
            B = human_t.size(0)
            xxx = self.human.unsqueeze(0).expand(B, 1, self.hidden_size)
            # 对人类数据执行拼接
            #human_x_final = torch.cat([human_t, human_t, human_x], dim=1)
            human_x_final = torch.cat([human_t, xxx, human_x], dim=1)
            x_final[human_mask] = human_x_final
        x = x_final
        # breakpoint()
        
        # Add multimodal position embeddings
        x = x + self.x_pos_embed[:, 0:10, :]
        # Note the lang is of variable length
        lang_c = lang_c + self.lang_cond_pos_embed[:, :lang_c.shape[1]]

        # print("--------------------------------------")
        # print(lang_c.shape)
        # print("--------------------------------------")

        img_c = img_c + self.img_cond_pos_embed

        # Forward pass
        conds = [lang_c, img_c]
        masks = [lang_mask, img_mask]
        for i, block in enumerate(self.blocks):
            c, mask = conds[i%2], masks[i%2]
            x = block(x, c, mask)                       # (B, T+1, D)
        # Inject the language condition at the final layer
        #x = self.final_layer(x)                         # (B, T+1, out_channels)

        # 初始化结果张量
        #256 4096
        x_final = torch.zeros(
            x.shape[0], x.shape[1], 256,  # 最终输出的维度为 (B, T, 256) 512
            device=x.device
        )
        # 分组处理
        if robot_mask.any():  # 如果有机器人数据
            robot_x = x[robot_mask]  # 提取机器人对应的 x
            robot_x_final = self.final_layer_robot(robot_x)  # 使用机器人 final_layer 处理
            #--------------------------------------
            #robot_x_final = self.final_layer(robot_x)  # 使用机器人 final_layer 处理

            # Padding 机器人数据的最后一维到 256
            # 4096 256 512
            robot_x_padded = torch.zeros(
                robot_x_final.shape[0], robot_x_final.shape[1], 256,
                device=robot_x_final.device
            )
            robot_x_padded[..., :7] = robot_x_final  # 填充前 7 维
            x_final[robot_mask] = robot_x_padded  # 填充到最终结果
        if human_mask.any():  # 如果有人工数据
            human_x = x[human_mask]  # 提取人类对应的 x
            human_x_final = self.final_layer_human(human_x)  # 使用人类 final_layer 处理
            x_final[human_mask] = human_x_final  # 直接填充到最终结果
        x = x_final
        # x_final 即为最终结果，形状为 (B, T, 256)
        # Only preserve the action tokens
        x = x[:, -self.horizon:]

        return x




# class RDTxxx(nn.Module):
#     """
#     Class for Robotics Diffusion Transformers.
#     """
#     def __init__(
#         self,
#         output_dim=128,
#         horizon=32,
#         hidden_size=1152,
#         depth=28,
#         num_heads=16,
#         max_lang_cond_len=1024,
#         img_cond_len=4096,
#         lang_pos_embed_config=None,
#         img_pos_embed_config=None,
#         dtype=torch.float32
#     ):
#         super().__init__()
#         self.horizon = horizon
#         self.hidden_size = hidden_size
#         self.max_lang_cond_len = max_lang_cond_len
#         self.img_cond_len = img_cond_len
#         self.dtype = dtype
#         self.lang_pos_embed_config = lang_pos_embed_config
#         self.img_pos_embed_config = img_pos_embed_config

#         self.t_embedder = TimestepEmbedder(hidden_size, dtype=dtype)
#         self.freq_embedder = TimestepEmbedder(hidden_size, dtype=dtype)
        
#         # We will use trainable sin-cos embeddings
#         # [timestep; state; action]
#         self.x_pos_embed = nn.Parameter(
#             torch.zeros(1, horizon+3, hidden_size))
#         # Language conditions
#         self.lang_cond_pos_embed = nn.Parameter(
#             torch.zeros(1, max_lang_cond_len, hidden_size))
#         # Image conditions
#         self.img_cond_pos_embed = nn.Parameter(
#             torch.zeros(1, img_cond_len, hidden_size))

#         self.blocks = nn.ModuleList([
#             RDTBlock(hidden_size, num_heads) for _ in range(depth)
#         ])

#         self.blocks_robot = nn.ModuleList([
#             RDTBlock(hidden_size, num_heads) for _ in range(depth)
#         ])


#         self.final_layer = FinalLayer(hidden_size, output_dim)


#         self.final_layer = FinalLayer(hidden_size, output_dim)

#         self.final_layer_robot = FinalLayer(hidden_size, 7)
#         self.final_layer_human = FinalLayer(hidden_size, 64)

#         self.robot = nn.Parameter(torch.zeros(1, self.hidden_size))
#         self.human = nn.Parameter(torch.zeros(1, self.hidden_size))

#         self.initialize_weights()

#     def initialize_weights(self):
#         # Initialize transformer layers:
#         def _basic_init(module):
#             if isinstance(module, nn.Linear):
#                 torch.nn.init.xavier_uniform_(module.weight)
#                 if module.bias is not None:
#                     nn.init.constant_(module.bias, 0)
#         self.apply(_basic_init)

#         # Initialize pos_embed by sin-cos embedding
#         x_pos_embed = get_multimodal_cond_pos_embed(
#             embed_dim=self.hidden_size,
#             mm_cond_lens=OrderedDict([
#                 ('timestep', 1),
#                 ('ctrl_freq', 1),
#                 ('state', 1),
#                 ('action', self.horizon),
#             ])
#         )
#         self.x_pos_embed.data.copy_(torch.from_numpy(x_pos_embed).float().unsqueeze(0))

#         if self.lang_pos_embed_config is None:
#             lang_cond_pos_embed = get_1d_sincos_pos_embed_from_grid(
#                 self.hidden_size, torch.arange(self.max_lang_cond_len))
#         else:
#             lang_cond_pos_embed = get_multimodal_cond_pos_embed(
#                 embed_dim=self.hidden_size,
#                 mm_cond_lens=OrderedDict(self.lang_pos_embed_config),
#                 embed_modality=False
#             )
#         self.lang_cond_pos_embed.data.copy_(
#             torch.from_numpy(lang_cond_pos_embed).float().unsqueeze(0))

#         # breakpoint()
        
#         if self.img_pos_embed_config is None:
#             img_cond_pos_embed = get_1d_sincos_pos_embed_from_grid(
#                 self.hidden_size, torch.arange(self.img_cond_len))
#         else:
#             img_cond_pos_embed = get_multimodal_cond_pos_embed(
#                 embed_dim=self.hidden_size,
#                 mm_cond_lens=OrderedDict(self.img_pos_embed_config),
#                 embed_modality=False
#             )
#         self.img_cond_pos_embed.data.copy_(
#             torch.from_numpy(img_cond_pos_embed).float().unsqueeze(0))

#         # Initialize timestep and control freq embedding MLP
#         nn.init.normal_(self.t_embedder.mlp[0].weight, std=0.02)
#         nn.init.normal_(self.t_embedder.mlp[2].weight, std=0.02)
#         nn.init.normal_(self.freq_embedder.mlp[0].weight, std=0.02)
#         nn.init.normal_(self.freq_embedder.mlp[2].weight, std=0.02)
            
#         # Initialize the final layer: zero-out the final linear layer
#         nn.init.constant_(self.final_layer.ffn_final.fc2.weight, 0)
#         nn.init.constant_(self.final_layer.ffn_final.fc2.bias, 0)

#         nn.init.constant_(self.final_layer_robot.ffn_final.fc2.weight, 0)
#         nn.init.constant_(self.final_layer_robot.ffn_final.fc2.bias, 0)

#         nn.init.constant_(self.final_layer_human.ffn_final.fc2.weight, 0)
#         nn.init.constant_(self.final_layer_human.ffn_final.fc2.bias, 0)
        
#         # Move all the params to given data type:
#         self.to(self.dtype)

    
#     #没有本地状态就用两个t

#     def forward(self, x, freq, t, lang_c, img_c, state_c, isrobot, latent, lang_mask=None, img_mask=None):
#         """
#         Forward pass of RDT.
        
#         x: (B, T, D), state + action token sequence, T = horizon + 1,
#             dimension D is assumed to be the same as the hidden size.
#         freq: (B,), a scalar indicating control frequency.
#         t: (B,) or (1,), diffusion timesteps.
#         lang_c: (B, L_lang, D) or None, language condition tokens (variable length),
#             dimension D is assumed to be the same as the hidden size.
#         img_c: (B, L_img, D) or None, image condition tokens (fixed length),
#             dimension D is assumed to be the same as the hidden size.
#         lang_mask: (B, L_lang) or None, language condition mask (True for valid).
#         img_mask: (B, L_img) or None, image condition mask (True for valid).
#         """

#         lang_mask = None


#         t = self.t_embedder(t).unsqueeze(1)             # (B, 1, D) or (1, 1, D)
#         #freq = self.freq_embedder(freq).unsqueeze(1)    # (B, 1, D)
#         # Append timestep to the input tokens
#         if t.shape[0] == 1:
#             t = t.expand(x.shape[0], -1, -1)


#         # 这部分要修改
#         #x = torch.cat([t, state_c, x], dim=1)               # (B, T+1, D)
#         #x = torch.cat([t, t, x], dim=1)               # (B, T+1, D)

#         # 根据 isrobot 分组
#         robot_mask = isrobot  # 机器人数据的布尔掩码
#         human_mask = ~isrobot  # 人类数据的布尔掩码
#         # 初始化结果张量
#         x_final = torch.zeros(
#             x.shape[0], x.shape[1] + t.shape[1] + t.shape[1], x.shape[2],  # 最终拼接后的维度
#             device=x.device
#         )
#         # 分组处理
#         if robot_mask.any():  # 如果有机器人数据
#             robot_t = t[robot_mask]
#             robot_state_c = state_c[robot_mask]
#             robot_x = x[robot_mask]
#             # 对机器人数据执行拼接
#             #robot_x_final = torch.cat([robot_t, robot_state_c + self.robot, robot_x], dim=1)
#             robot_x_final = torch.cat([robot_t, robot_state_c, robot_x], dim=1)
#             x_final[robot_mask] = robot_x_final

#         if human_mask.any():  # 如果有人工数据
            
#             human_t = t[human_mask]
#             human_x = x[human_mask]
#             B = human_t.size(0)
#             xxx = self.human.unsqueeze(0).expand(B, 1, self.hidden_size)
#             # 对人类数据执行拼接
#             #human_x_final = torch.cat([human_t, human_t, human_x], dim=1)
#             human_x_final = torch.cat([human_t, xxx, human_x], dim=1)
#             x_final[human_mask] = human_x_final
#         x = x_final
#         # breakpoint()
        
#         # Add multimodal position embeddings
#         x = x + self.x_pos_embed[:, 0:10, :]
#         # Note the lang is of variable length
        
        
#         lang_c = lang_c + self.lang_cond_pos_embed[:, :lang_c.shape[1]]
#         img_c = img_c + self.img_cond_pos_embed

#         if latent is not None:
#             img_c = torch.cat([img_c, latent], dim=1)

#         # Forward pass
#         conds = [lang_c, img_c]
#         masks = [lang_mask, img_mask]

#         if robot_mask.any():
#             for i, block in enumerate(self.blocks_robot):
#                 c, mask = conds[i%2], masks[i%2]
#                 x = block(x, c, mask)
#         else:
#             for i, block in enumerate(self.blocks):
#                 c, mask = conds[i%2], masks[i%2]
#                 x = block(x, c, mask)
#         # for i, block in enumerate(self.blocks):
#         #     c, mask = conds[i%2], masks[i%2]
#         #     x = block(x, c, mask)                       # (B, T+1, D)
#         # Inject the language condition at the final layer
#         #x = self.final_layer(x)                         # (B, T+1, out_channels)


#         # 初始化结果张量
#         x_final = torch.zeros(
#             x.shape[0], x.shape[1], 256,  # 最终输出的维度为 (B, T, 256)
#             device=x.device
#         )
#         # 分组处理
#         if robot_mask.any():  # 如果有机器人数据
#             robot_x = x[robot_mask]  # 提取机器人对应的 x
#             robot_x_final = self.final_layer_robot(robot_x)  # 使用机器人 final_layer 处理
#             # Padding 机器人数据的最后一维到 256
#             robot_x_padded = torch.zeros(
#                 robot_x_final.shape[0], robot_x_final.shape[1], 256,
#                 device=robot_x_final.device
#             )
#             robot_x_padded[..., :7] = robot_x_final  # 填充前 7 维
#             x_final[robot_mask] = robot_x_padded  # 填充到最终结果
#         if human_mask.any():  # 如果有人工数据
#             human_x = x[human_mask]  # 提取人类对应的 x
#             human_x_final = self.final_layer_human(human_x)  # 使用人类 final_layer 处理
#             x_final[human_mask] = human_x_final  # 直接填充到最终结果
#         x = x_final
#         # x_final 即为最终结果，形状为 (B, T, 256)
#         # Only preserve the action tokens
#         x = x[:, -self.horizon:]

#         # breakpoint()

#         return x