import re
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers.schedulers.scheduling_ddpm import DDPMScheduler
from diffusers.schedulers.scheduling_dpmsolver_multistep import \
    DPMSolverMultistepScheduler

from atm.policy.RoboticsDiffusionTransformer.models.hub_mixin import CompatiblePyTorchModelHubMixin
from atm.policy.RoboticsDiffusionTransformer.models.rdt.model import RDT


'''
统计policy和四个adapter的参数
都算成diffusion的
机器人和视频数据 两个个动作维度是不一致的
'''

class RDTRunner(
        nn.Module, 
        CompatiblePyTorchModelHubMixin, 
        repo_url="https://huggingface.co/robotics-diffusion-transformer/rdt-1b"
    ):
    def __init__(self, *, action_dim, pred_horizon, config, 
                 lang_token_dim, img_token_dim, state_token_dim, 
                 max_lang_cond_len, img_cond_len, lang_pos_embed_config=None, 
                 img_pos_embed_config=None, dtype=torch.float32):
        super(RDTRunner, self).__init__()
        # Create diffusion model
        hidden_size = config['rdt']['hidden_size']
        self.model = RDT(
            output_dim=action_dim,
            horizon=pred_horizon,
            hidden_size=hidden_size,
            depth=config['rdt']['depth'],
            num_heads=config['rdt']['num_heads'],
            max_lang_cond_len=max_lang_cond_len,
            img_cond_len=img_cond_len,
            lang_pos_embed_config=lang_pos_embed_config,
            img_pos_embed_config=img_pos_embed_config,
            dtype=dtype,
        )

        # breakpoint()

        # Create adpators for various conditional inputs
        self.lang_adaptor = self.build_condition_adapter(
            config['lang_adaptor'], 
            in_features=lang_token_dim, 
            out_features=hidden_size
        )
        self.img_adaptor = self.build_condition_adapter(
            config['img_adaptor'], 
            in_features=img_token_dim, 
            out_features=hidden_size
        )
        # A `state` refers to an action or a proprioception vector
        self.state_adaptor = self.build_condition_adapter(
            config['state_adaptor'], 
            in_features=state_token_dim ,    # state + state mask (indicator)
            out_features=hidden_size
        )
        #---------------------------------------------------------------------- 7 - 256
        # self.action_adaptor = self.build_condition_adapter(
        #     config['state_adaptor'], 
        #     #############################
        #     in_features=256 ,    # state + state mask (indicator)
        #     out_features=hidden_size
        # )

        # self.guide = self.build_condition_adapter(
        #     config['state_adaptor'], 
        #     in_features=256 ,    # state + state mask (indicator)
        #     out_features=hidden_size
        # )


        # co-training的好处在于更通用 不会过拟合  你现在finetuning和condition不好的原因都在于过拟合 下游数据太少
        ###############################################################################
        self.action_adaptor_human = self.build_condition_adapter(
            config['state_adaptor'], 
            in_features=256,    # state + state mask (indicator) 256 512
            out_features=hidden_size
        )
        #4096 256

        self.action_adaptor_robot = self.build_condition_adapter(
            config['state_adaptor'], 
            in_features=7,    # state + state mask (indicator)
            out_features=hidden_size
        )

        # breakpoint()
        
        
        # Create the noise scheduler
        noise_scheduler_config = config['noise_scheduler']
        self.noise_scheduler = DDPMScheduler(
            num_train_timesteps=noise_scheduler_config['num_train_timesteps'],
            beta_schedule=noise_scheduler_config['beta_schedule'],
            prediction_type=noise_scheduler_config['prediction_type'],
            clip_sample=noise_scheduler_config['clip_sample'],
        )
        self.noise_scheduler_sample = DPMSolverMultistepScheduler(
            num_train_timesteps=noise_scheduler_config['num_train_timesteps'],
            beta_schedule=noise_scheduler_config['beta_schedule'],
            prediction_type=noise_scheduler_config['prediction_type'],
        )

        self.num_train_timesteps = noise_scheduler_config['num_train_timesteps']
        self.num_inference_timesteps = noise_scheduler_config['num_inference_timesteps']
        self.prediction_type = noise_scheduler_config['prediction_type']

        self.pred_horizon = pred_horizon
        self.action_dim = action_dim

        print("Diffusion params: %e" % sum(
            [p.numel() for p in self.model.parameters()] + 
            [p.numel() for p in self.lang_adaptor.parameters()] + 
            [p.numel() for p in self.img_adaptor.parameters()] + 
            [p.numel() for p in self.state_adaptor.parameters()] + 
            [p.numel() for p in self.action_adaptor_human.parameters()]))
    
    def build_condition_adapter(
        self, projector_type, in_features, out_features):


        projector = None
        if projector_type == 'linear':
            projector = nn.Linear(in_features, out_features)
        else:
            mlp_gelu_match = re.match(r'^mlp(\d+)x_gelu$', projector_type)
            if mlp_gelu_match:
                mlp_depth = int(mlp_gelu_match.group(1))
                modules = [nn.Linear(in_features, out_features)]
                for _ in range(1, mlp_depth):
                    modules.append(nn.GELU(approximate="tanh"))
                    modules.append(nn.Linear(out_features, out_features))
                projector = nn.Sequential(*modules)

        if projector is None:
            raise ValueError(f'Unknown projector type: {projector_type}')

        return projector
    
    def adapt_conditions(self, lang_tokens, img_tokens, state_tokens, action_tokens, isrobot):
        '''
        lang_tokens: (batch_size, lang_len, lang_token_dim)
        img_tokens: (batch_size, img_len, img_token_dim)
        state_tokens: (batch_size, state_len, state_token_dim)
        
        return: adpated (..., hidden_size) for all input tokens
        '''

        # lang_tokens = lang_tokens.float32()
        # img_tokens = img_tokens.float32()
        # state_tokens = state_tokens.float32()
        # action_tokens = action_tokens.float32()

        lang_tokens = lang_tokens.to(dtype=torch.float32)
        img_tokens = img_tokens.to(dtype=torch.float32)
        state_tokens = state_tokens.to(dtype=torch.float32)
        action_tokens = action_tokens.to(dtype=torch.float32)


        adpated_lang = self.lang_adaptor(lang_tokens)
        adpated_img = self.img_adaptor(img_tokens)
        adpated_state = self.state_adaptor(state_tokens)

        #这个地方要修改
        #adpated_action = self.action_adaptor(action_tokens)

        # 根据 isrobot 分组
        robot_mask = isrobot  # 机器人数据的布尔掩码
        human_mask = ~isrobot  # 人类数据的布尔掩码
        # 分别处理机器人和人类动作
        robot_actions = action_tokens[robot_mask]  # 提取机器人数据
        human_actions = action_tokens[human_mask]  # 提取人类数据
        # 检查是否有机器人数据
        if robot_actions.shape[0] > 0:  
            robot_actions = robot_actions[..., :7]  # 截断到前 7 维
            #-------------------------------------
            adapted_robot_actions = self.action_adaptor_robot(robot_actions)
            #adapted_robot_actions = self.action_adaptor(robot_actions)
        else:
            adapted_robot_actions = None
        # 检查是否有人工数据
        if human_actions.shape[0] > 0:  
            adapted_human_actions = self.action_adaptor_human(human_actions)
        else:
            adapted_human_actions = None
        # 初始化结果张量，确保设备一致
        adpated_action = torch.zeros(
            action_tokens.shape[0], action_tokens.shape[1], 
            adapted_robot_actions.shape[-1] if adapted_robot_actions is not None else adapted_human_actions.shape[-1],
            device=action_tokens.device
        )
        # 填充机器人和人类的结果，保持原始顺序
        if adapted_robot_actions is not None:
            adpated_action[robot_mask] = adapted_robot_actions
        if adapted_human_actions is not None:
            adpated_action[human_mask] = adapted_human_actions

        return adpated_lang, adpated_img, adpated_state, adpated_action


    

    #人类动作推理 人类动作目前是8*16*2=256维度的 和机器人的动作推理没什么两样
    def conditional_sample2(self, lang_cond, lang_attn_mask, img_cond, 
                           state_traj, action_mask, ctrl_freqs, isrobot):
        '''
        lang_cond: language conditional data, (batch_size, lang_len, hidden_size).
        lang_attn_mask: (batch_size, lang_len), a mask for valid language tokens,
            which should be True-False bool tensor.
        img_cond: image conditional data, (batch_size, img_len, hidden_size).
        state_traj: (batch_size, 1, hidden_size), state trajectory.
        action_mask: (batch_size, 1, action_dim), a 0-1 **float** tensor
            indicating the valid action dimensions.
        ctrl_freqs: (batch_size,), control frequency for each sample.
        
        return: (batch_size, horizon, action_dim)
        '''
        device = state_traj.device
        dtype = state_traj.dtype
        noisy_action = torch.randn(
            size=(state_traj.shape[0], self.pred_horizon, self.action_dim), 
            dtype=dtype, device=device)
        #action_mask = action_mask.expand(-1, self.pred_horizon, -1)
    
        # Set step values
        self.noise_scheduler_sample.set_timesteps(self.num_inference_timesteps)
        
        for t in self.noise_scheduler_sample.timesteps:
            # Prepare state-action trajectory
            #action_traj = torch.cat([noisy_action, action_mask], dim=2)
            action_traj = noisy_action
           
            #action_traj = action_traj[..., :7]
            #用的参数的key不一样
            #action_traj = self.action_adaptor(action_traj)
            action_traj = self.action_adaptor_human(action_traj)


            state_action_traj = state_traj
            
            # Predict the model output
            # model_output = self.model(action_traj, ctrl_freqs,
            #                         t.unsqueeze(-1).to(device),
            #                         lang_cond, img_cond, state_action_traj, isrobot, lang_mask=lang_attn_mask)
            model_output = self.model(action_traj, ctrl_freqs,
                                    t.unsqueeze(-1).to(device),
                                    lang_cond, img_cond, state_action_traj, isrobot, latent = None, lang_mask=lang_attn_mask)
            
            # Compute previous actions: x_t -> x_t-1
            noisy_action = self.noise_scheduler_sample.step(
                model_output, t, noisy_action).prev_sample
            noisy_action = noisy_action.to(state_traj.dtype)
        
        # Finally apply the action mask to mask invalid action dimensions
        # noisy_action = noisy_action * action_mask

        return noisy_action


    # 正常的机器人动作推理
    def conditional_sample(self, lang_cond, lang_attn_mask, img_cond, 
                           state_traj, action_mask, ctrl_freqs, isrobot):
        '''
        lang_cond: language conditional data, (batch_size, lang_len, hidden_size).
        lang_attn_mask: (batch_size, lang_len), a mask for valid language tokens,
            which should be True-False bool tensor.
        img_cond: image conditional data, (batch_size, img_len, hidden_size).
        state_traj: (batch_size, 1, hidden_size), state trajectory.
        action_mask: (batch_size, 1, action_dim), a 0-1 **float** tensor
            indicating the valid action dimensions.
        ctrl_freqs: (batch_size,), control frequency for each sample.
        
        return: (batch_size, horizon, action_dim)
        
        '''

        #生成这个随机动作的时候，对于机器人动作，还是生成了256维的，但是只用了7维。

        self.action_dim = 7

        device = state_traj.device
        dtype = state_traj.dtype
        noisy_action = torch.randn(
            size=(state_traj.shape[0], self.pred_horizon, self.action_dim), 
            dtype=dtype, device=device)
        #action_mask = action_mask.expand(-1, self.pred_horizon, -1)
    
        # Set step values
        self.noise_scheduler_sample.set_timesteps(self.num_inference_timesteps)
        

        '''
        对于这个循环，每次输入都是noisy_action，他被更新的 其实就是model的输出 对于机器人数据 后面都是0
        '''
        # noisy_action每次都的得到了7维 扩充到256 再到7

        for t in self.noise_scheduler_sample.timesteps:
            # Prepare state-action trajectory
            #action_traj = torch.cat([noisy_action, action_mask], dim=2)
            action_traj = noisy_action
           
            action_traj = action_traj[..., :7]
            #用的参数的key不一样
            #action_traj = self.action_adaptor(action_traj)
            #-----------------------------------
            action_traj = self.action_adaptor_robot(action_traj)
            #action_traj = self.action_adaptor(action_traj)


            #action_traj = action_traj + latent


            state_action_traj = state_traj
            
            # Predict the model output
            model_output = self.model(action_traj, ctrl_freqs,
                                    t.unsqueeze(-1).to(device),
                                    lang_cond, img_cond, state_action_traj, isrobot, lang_mask=lang_attn_mask)
            
            model_output = model_output[..., :7]

            
            # Compute previous actions: x_t -> x_t-1
            noisy_action = self.noise_scheduler_sample.step(
                model_output, t, noisy_action).prev_sample
            noisy_action = noisy_action.to(state_traj.dtype)
        
        # Finally apply the action mask to mask invalid action dimensions
        # noisy_action = noisy_action * action_mask

        return noisy_action

    



    #latent action做condition的action推理
    #现在的condiiton方式相当于在每次forward的时候都做了相加的condiiton融合
    #第二步就是做attention了
    def conditional_sample3(self, lang_cond, lang_attn_mask, img_cond, 
                           state_traj, action_mask, ctrl_freqs, isrobot, latent):
        '''
        lang_cond: language conditional data, (batch_size, lang_len, hidden_size).
        lang_attn_mask: (batch_size, lang_len), a mask for valid language tokens,
            which should be True-False bool tensor.
        img_cond: image conditional data, (batch_size, img_len, hidden_size).
        state_traj: (batch_size, 1, hidden_size), state trajectory.
        action_mask: (batch_size, 1, action_dim), a 0-1 **float** tensor
            indicating the valid action dimensions.
        ctrl_freqs: (batch_size,), control frequency for each sample.
        
        return: (batch_size, horizon, action_dim)
        '''
        device = state_traj.device
        dtype = state_traj.dtype
        noisy_action = torch.randn(
            size=(state_traj.shape[0], self.pred_horizon, self.action_dim), 
            dtype=dtype, device=device)
        #action_mask = action_mask.expand(-1, self.pred_horizon, -1)
    
        # Set step values
        self.noise_scheduler_sample.set_timesteps(self.num_inference_timesteps)

        #noisy_action = noisy_action + latent

        #max = 0
        
        for t in self.noise_scheduler_sample.timesteps:
            # Prepare state-action trajectory
            #action_traj = torch.cat([noisy_action, action_mask], dim=2)
            action_traj = noisy_action
           
            action_traj = action_traj[..., :7]
            #用的参数的key不一样
            #action_traj = self.action_adaptor(action_traj)
            action_traj = self.action_adaptor_robot(action_traj)


            state_action_traj = state_traj
            
            #Predict the model output
            action_traj = action_traj + latent
            model_output = self.model(action_traj, ctrl_freqs,
                                    t.unsqueeze(-1).to(device),
                                    lang_cond, img_cond, state_action_traj, isrobot, latent=None, lang_mask=lang_attn_mask)

            # model_output = self.model(action_traj, ctrl_freqs,
            #                         t.unsqueeze(-1).to(device),
            #                         lang_cond, img_cond, state_action_traj, isrobot, latent=latent, lang_mask=lang_attn_mask)
            


            
            # Compute previous actions: x_t -> x_t-1
            noisy_action = self.noise_scheduler_sample.step(
                model_output, t, noisy_action).prev_sample
            noisy_action = noisy_action.to(state_traj.dtype)

            #max = max + 1 
        
        # Finally apply the action mask to mask invalid action dimensions
        # noisy_action = noisy_action * action_mask

        return noisy_action


    
    # condition的训练
    def compute_loss2(self, lang_tokens, lang_attn_mask, img_tokens, 
                     state_tokens, action_gt, action_mask, ctrl_freqs, isrobot
                    ) -> torch.Tensor:
        '''
        lang_tokens: (batch_size, lang_len, lang_token_dim)
        lang_attn_mask: (batch_size, lang_len), a mask for valid language tokens,
            which should be True-False bool tensor.
        img_tokens: (batch_size, img_len, img_token_dim)
        state_tokens: (batch_size, 1, state_token_dim)
        action_gt: (batch_size, horizon, state_token_dim), ground-truth actions for supervision
        action_mask: (batch_size, 1, state_token_dim), a 0-1 **float** tensor.
        ctrl_freqs: (batch_size,), control frequency for each sample.
        
        return: loss_value, a scalar tensor
        '''
        ppp = torch.zeros(
        state_tokens.shape[0],  # 第一个维度
        state_tokens.shape[1],  # 第二个维度
        256,                      # 第三个维度固定为 7
        dtype=state_tokens.dtype,  # 数据类型与 state_tokens 一致
        device=state_tokens.device  # 设备与 state_tokens 一致
        )
        B = state_tokens.shape[0]
        #isrobot_human = torch.ones(B, dtype=torch.bool, device=state_tokens.device)
        isrobot_human = torch.zeros(B, dtype=torch.bool, device=state_tokens.device)
        lang_cond, img_cond, state_traj, ppp = self.adapt_conditions(
            lang_tokens.unsqueeze(1), img_tokens, state_tokens, ppp, isrobot_human)
        
        # Run sampling
        action_pred = self.conditional_sample2(
            lang_cond, lang_attn_mask, img_cond, 
            state_traj, action_mask, ctrl_freqs, isrobot_human
        )

        isrobot_robot = torch.ones(B, dtype=torch.bool, device=state_tokens.device)

        batch_size = lang_tokens.shape[0]
        device = lang_tokens.device  

        # Sample noise that we'll add to the actions
        noise = torch.randn(
            action_gt.shape, dtype=action_gt.dtype, device=device
        )
        # Sample random diffusion timesteps
        timesteps = torch.randint(
            0, self.num_train_timesteps, 
            (batch_size,), device=device
        ).long() #bs
        # Add noise to the clean actions according to the noise magnitude at each timestep
        # (this is the forward diffusion process)
        noisy_action = self.noise_scheduler.add_noise(
            action_gt, noise, timesteps)     # bs t 7
        
        # Align the dimension with the hidden size
        lang_cond, img_cond, state_cond, state_action_traj = self.adapt_conditions(
            lang_tokens.unsqueeze(1), img_tokens, state_tokens, noisy_action, isrobot_robot)
        
          
        #breakpoint()
        # 不管是哪一等级的噪声，都和latent进行相加融合后再去forward


        #state_action_traj = state_action_traj + self.guide(action_pred)
        latent = self.guide(action_pred)

     
        #pred = self.model(state_action_traj, ctrl_freqs, timesteps, lang_cond, img_cond, state_cond, isrobot_robot, lang_mask=lang_attn_mask)
        pred = self.model(state_action_traj, ctrl_freqs, timesteps, lang_cond, img_cond, state_cond, isrobot_robot, latent, lang_mask=lang_attn_mask)

        pred_type = self.prediction_type 
        if pred_type == 'epsilon':
            target = noise
        elif pred_type == 'sample':
            target = action_gt
        else:
            raise ValueError(f"Unsupported prediction type {pred_type}")
        #这个部分要修改
        #loss = F.mse_loss(pred, target)

        robot_mask = isrobot_robot  # 机器人数据的布尔掩码
        human_mask = ~isrobot_robot  # 人类数据的布尔掩码
        # 初始化总损失
        loss = 0.0
        # 机器人数据的损失计算
        if robot_mask.any():  # 如果有机器人数据
            robot_pred = pred[robot_mask][..., :7]  # 提取机器人预测的前 7 维
            robot_target = target[robot_mask][..., :7]  # 提取机器人目标的前 7 维
            # 计算机器人数据的 MSE Loss
            robot_loss = F.mse_loss(robot_pred, robot_target)
            loss += robot_loss
        # 人类数据的损失计算
        if human_mask.any():  # 如果有人工数据
            human_pred = pred[human_mask]  # 提取人类预测的完整 256 维
            human_target = target[human_mask]  # 提取人类目标的完整 256 维
            # 计算人类数据的 MSE Loss
            human_loss = F.mse_loss(human_pred, human_target)
            loss += human_loss
        return loss


    




    # ========= Train  ============
    def compute_loss(self, lang_tokens, lang_attn_mask, img_tokens, 
                     state_tokens, action_gt, action_mask, ctrl_freqs, isrobot
                    ) -> torch.Tensor:
        '''
        lang_tokens: (batch_size, lang_len, lang_token_dim)
        lang_attn_mask: (batch_size, lang_len), a mask for valid language tokens,
            which should be True-False bool tensor.
        img_tokens: (batch_size, img_len, img_token_dim)
        state_tokens: (batch_size, 1, state_token_dim)
        action_gt: (batch_size, horizon, state_token_dim), ground-truth actions for supervision
        action_mask: (batch_size, 1, state_token_dim), a 0-1 **float** tensor.
        ctrl_freqs: (batch_size,), control frequency for each sample.
        
        return: loss_value, a scalar tensor
        '''
        batch_size = lang_tokens.shape[0]
        device = lang_tokens.device  

        # Sample noise that we'll add to the actions
        noise = torch.randn(
            action_gt.shape, dtype=action_gt.dtype, device=device
        )
        # Sample random diffusion timesteps
        timesteps = torch.randint(
            0, self.num_train_timesteps, 
            (batch_size,), device=device
        ).long() #bs
        # Add noise to the clean actions according to the noise magnitude at each timestep
        # (this is the forward diffusion process)
        noisy_action = self.noise_scheduler.add_noise(
            action_gt, noise, timesteps)     # bs t 7
        
        # Align the dimension with the hidden size
        lang_cond, img_cond, state_cond, state_action_traj = self.adapt_conditions(
            lang_tokens.unsqueeze(1), img_tokens, state_tokens, noisy_action, isrobot)


        # Predict the denoised result
        pred = self.model(state_action_traj, ctrl_freqs, timesteps, lang_cond, img_cond, state_cond, isrobot, lang_mask=lang_attn_mask)

        pred_type = self.prediction_type 
        if pred_type == 'epsilon':
            target = noise
        elif pred_type == 'sample':
            target = action_gt
        else:
            raise ValueError(f"Unsupported prediction type {pred_type}")
        
        #这个部分要修改
        #loss = F.mse_loss(pred, target)

        robot_mask = isrobot  # 机器人数据的布尔掩码
        human_mask = ~isrobot  # 人类数据的布尔掩码
        # 初始化总损失
        loss = 0.0
        # 机器人数据的损失计算
        if robot_mask.any():  # 如果有机器人数据
            robot_pred = pred[robot_mask][..., :7]  # 提取机器人预测的前 7 维
            robot_target = target[robot_mask][..., :7]  # 提取机器人目标的前 7 维
            # 计算机器人数据的 MSE Loss
            robot_loss = F.mse_loss(robot_pred, robot_target)
            loss += robot_loss
        # 人类数据的损失计算
        if human_mask.any():  # 如果有人工数据
            human_pred = pred[human_mask]  # 提取人类预测的完整 256 维
            human_target = target[human_mask]  # 提取人类目标的完整 256 维
            # 计算人类数据的 MSE Loss
            # 对于vq的×6.0看一看？6.0和3.0 对于不同的vq 学到的值可能也有区别 
            
            #不加对比需要/10.0 1024
            
            human_loss = F.mse_loss(human_pred, human_target)
            loss += human_loss
        
        # print(human_loss, robot_loss)

        return loss
    

    # 这个预测是只预测第二个action的 因为你测试的时候只有人类的视频数据
    # ========= Inference  ============
    def predict_action(self, lang_tokens, lang_attn_mask, img_tokens, state_tokens,
                       action_mask, ctrl_freqs, isrobot):

        # Prepare the state and conditions
        #state_tokens = torch.cat([state_tokens, action_mask], dim=2)


        # lang_cond, img_cond, state_traj = self.adapt_conditions(
        #     lang_tokens, img_tokens, state_tokens)


        ppp = torch.zeros(
        state_tokens.shape[0],  # 第一个维度
        state_tokens.shape[1],  # 第二个维度
        7,                      # 第三个维度固定为 7
        dtype=state_tokens.dtype,  # 数据类型与 state_tokens 一致
        device=state_tokens.device  # 设备与 state_tokens 一致
        )

        lang_cond, img_cond, state_traj, ppp = self.adapt_conditions(
            lang_tokens.unsqueeze(1), img_tokens, state_tokens, ppp, isrobot)
        
        
        # Run sampling
        action_pred = self.conditional_sample(
            lang_cond, lang_attn_mask, img_cond, 
            state_traj, action_mask, ctrl_freqs, isrobot
        )

        action_pred = action_pred[..., :7]
        
        return action_pred

    


    def predict_action2(self, lang_tokens, lang_attn_mask, img_tokens, state_tokens,
                       action_mask, ctrl_freqs, isrobot):



        ppp = torch.zeros(
        state_tokens.shape[0],  # 第一个维度
        state_tokens.shape[1],  # 第二个维度
        256,                      # 第三个维度固定为 7
        dtype=state_tokens.dtype,  # 数据类型与 state_tokens 一致
        device=state_tokens.device  # 设备与 state_tokens 一致
        )
        B = state_tokens.shape[0]
        #isrobot_human = torch.ones(B, dtype=torch.bool, device=state_tokens.device)
        isrobot_human = torch.zeros(B, dtype=torch.bool, device=state_tokens.device)
        lang_cond, img_cond, state_traj, ppp = self.adapt_conditions(
            lang_tokens.unsqueeze(1), img_tokens, state_tokens, ppp, isrobot_human)
        
        # Run sampling
        action_pred = self.conditional_sample2(
            lang_cond, lang_attn_mask, img_cond, 
            state_traj, action_mask, ctrl_freqs, isrobot_human
        )

        latentaction = self.guide(action_pred)

        isrobot_robot = torch.ones(B, dtype=torch.bool, device=state_tokens.device)
     
        ppp = torch.zeros(
        state_tokens.shape[0],  # 第一个维度
        state_tokens.shape[1],  # 第二个维度
        7,                      # 第三个维度固定为 7
        dtype=state_tokens.dtype,  # 数据类型与 state_tokens 一致
        device=state_tokens.device  # 设备与 state_tokens 一致
        )

        lang_cond, img_cond, state_traj, ppp = self.adapt_conditions(
            lang_tokens.unsqueeze(1), img_tokens, state_tokens, ppp, isrobot_robot)

        #state_traj = state_traj + latentaction
        
        # Run sampling
        action_pred = self.conditional_sample3(
            lang_cond, lang_attn_mask, img_cond, 
            state_traj, action_mask, ctrl_freqs, isrobot, latentaction
        )

        action_pred = action_pred[..., :7]
        
        return action_pred

    



    
    def forward(self, *args, **kwargs) -> torch.Tensor:
        return self.compute_loss(*args, **kwargs)
